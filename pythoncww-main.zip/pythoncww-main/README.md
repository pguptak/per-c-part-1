# pythoncww
This is the python code implementation of Perceptual Computing.
